﻿namespace RestSharp.Tests.SampleClasses
{
    public class BooleanTest
    {
        public bool Value { get; set; }
    }
}
